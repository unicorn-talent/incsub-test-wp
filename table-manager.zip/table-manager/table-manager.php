<?php
/*
* Plugin Name: table-manager
* Plugin URI:
* Description: This is a plugin to manage table data.
* Version: 1.0
* Requires at least:
* Requires PHP:
* Author: Julian Kevin
* Author URI:
* License:
* License URI:
* Update URI:
* Text Domain:
* Domain Path:
*/

// Ensure the plugin is loaded only in the admin area
if (is_admin()) {
  add_action('init', 'my_init');

  function my_init() {
      maybe_create_my_table();
      add_shortcode('my_form', 'my_shortcode_form');
      add_shortcode('my_list', 'my_shortcode_list');
  
      add_action('rest_api_init', 'register_custom_endpoints');
  }
  
  function maybe_create_my_table() {
      global $wpdb;
      $table_name = $wpdb->prefix . 'things';
  
      // Check if the table exists
      if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
          $sql = "CREATE TABLE $table_name (
              id INT NOT NULL AUTO_INCREMENT,
              name VARCHAR(255) NOT NULL,
              PRIMARY KEY (id)
          )";
          require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
          dbDelta($sql);
      }
  }
  
  function my_shortcode_form() {
      if ($_SERVER['REQUEST_METHOD'] === 'POST') {
          insert_data_to_my_table();
      }
      echo <<<FORM
      <form method="POST"> 
          <label for="thing_name">Thing's Name:</label>
          <input type="text" name="thing_name" id="thing_name"> 
          <input type="submit" value="Add Thing">
      </form>
      FORM;
  }
  
  function my_shortcode_list() {
      $data = get_my_table_data();
  
      // Display the data as a table
      echo '<table>';
      echo '<tr><th>ID</th><th>Name</th></tr>';
      foreach ($data as $row) {
          echo '<tr>';
          echo '<td>' . esc_html($row['id']) . '</td>';
          echo '<td>' . esc_html($row['name']) . '</td>';
          echo '</tr>';
      }
      echo '</table>';
  }
  
  function get_my_table_data() {
      global $wpdb;
      $table_name = $wpdb->prefix . 'things';
      $results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
      return $results;
  }
  
  function insert_data_to_my_table() {
      if (isset($_POST['thing_name']) && !empty($_POST['thing_name'])) {
          global $wpdb;
          $table_name = $wpdb->prefix . 'things';
          $data = array('name' => sanitize_text_field($_POST['thing_name']));
          $wpdb->insert($table_name, $data);
      }
  }
  
  // REST API Custom Endpoints
  function register_custom_endpoints() {
      register_rest_route('table-manager/v1', '/insert/', array(
          'methods' => 'POST',
          'callback' => 'rest_insert_data_to_my_table',
          'permission_callback' => function () {
              return current_user_can('manage_options');
          },
      ));
  
      register_rest_route('table-manager/v1', '/select/', array(
          'methods' => 'GET',
          'callback' => 'rest_get_my_table_data',
      ));
  }
  
  function rest_insert_data_to_my_table($data) {
      if (isset($data['name']) && !empty($data['name'])) {
          global $wpdb;
          $table_name = $wpdb->prefix . 'things';
          $inserted = $wpdb->insert($table_name, array('name' => sanitize_text_field($data['name'])));
  
          if ($inserted) {
              return array('status' => 'success', 'message' => 'Data inserted successfully.');
          } else {
              return array('status' => 'error', 'message' => 'Error inserting data.');
          }
      } else {
          return array('status' => 'error', 'message' => 'Name is required.');
      }
  }
  
  function rest_get_my_table_data($data) {
      $page = isset($data['page']) ? absint($data['page']) : 1;
      $per_page = isset($data['per_page']) ? absint($data['per_page']) : 10;
      $orderby = isset($data['orderby']) ? sanitize_text_field($data['orderby']) : 'id';
      $order = isset($data['order']) ? sanitize_text_field($data['order']) : 'ASC';
      $search = isset($data['search']) ? sanitize_text_field($data['search']) : '';
  
      return get_my_table_data_rest($page, $per_page, $orderby, $order, $search);
  }
  
  function get_my_table_data_rest($page, $per_page, $orderby, $order, $search) {
      global $wpdb;
      $table_name = $wpdb->prefix . 'things';
  
      $offset = ($page - 1) * $per_page;
      $where = '';
  
      if (!empty($search)) {
          $where = $wpdb->prepare("WHERE name LIKE '%%%s%%'", $search);
      }
  
      $sql = $wpdb->prepare("SELECT * FROM $table_name $where ORDER BY $orderby $order LIMIT %d OFFSET %d", $per_page, $offset);
  
      $results = $wpdb->get_results($sql, ARRAY_A);
  
      return $results;
  }
}
